const form = document.querySelector("#pledge-form");
const amountSelect = document.querySelector("#amount");
const customWrap = document.querySelector("#custom-amount-wrap");
const customAmount = document.querySelector("#customAmount");
const status = document.querySelector("#form-status");

document.querySelector("#year").textContent = new Date().getFullYear();

amountSelect.addEventListener("change", () => {
  const isCustom = amountSelect.value === "custom";
  customWrap.hidden = !isCustom;
  customAmount.required = isCustom;
  if (!isCustom) customAmount.value = "";
});

form.addEventListener("submit", (event) => {
  event.preventDefault();

  const name = document.querySelector("#fullName").value.trim();
  const selectedAmount = amountSelect.value;
  const amount = selectedAmount === "custom"
    ? Number(customAmount.value)
    : Number(selectedAmount);
  const message = document.querySelector("#message").value.trim();

  if (!name) {
    status.textContent = "Please enter your name.";
    return;
  }
  if (!Number.isFinite(amount) || amount < 1 || amount > 1000000) {
    status.textContent = "Please choose or enter a valid amount between ₹1 and ₹10,00,000.";
    return;
  }

  // Demo only: store the pledge in this browser, not on a server.
  const pledge = {
    name,
    amount,
    message,
    createdAt: new Date().toISOString()
  };

  try {
    const existing = JSON.parse(sessionStorage.getItem("molsomPledges") || "[]");
    existing.push(pledge);
    sessionStorage.setItem("molsomPledges", JSON.stringify(existing));
    status.textContent = `Thank you, ${name}. Your ₹${amount.toLocaleString("en-IN")} pledge was saved in this browser session only. No payment was made.`;
    form.reset();
    customWrap.hidden = true;
    customAmount.required = false;
  } catch {
    status.textContent = "Your browser could not save this pledge. Please try again.";
  }
});
